DROP DATABASE IF EXISTS SuperHeroSightings;
CREATE DATABASE SuperHeroSightings;
USE SuperHeroSightings;

-- Table structure for `Superpower`
CREATE TABLE `Superpower`(
	`SuperpowerID` INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
	`PowerName` VARCHAR(45) NOT NULL
);

-- Table structure for table `Game`
CREATE TABLE `Hero`(
	`HeroID` INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
	`HeroName` VARCHAR(45) NOT NULL,
	`HeroDescription` VARCHAR(45)
);

-- Table structure for table `HeroHasSuperpower`
CREATE TABLE `HeroHasSuperpower`(
	`HeroID` INT UNSIGNED, 
    `SuperpowerID`  INT UNSIGNED, 
    PRIMARY KEY pk_HeroSuperpower (`HeroID`,`SuperpowerID`),
    FOREIGN KEY fk_HeroHasSuperPower_Hero (`HeroID`) REFERENCES `Hero`(`HeroID`),
	FOREIGN KEY fk_HeroHasSuperPower_Superpower (`SuperpowerID`) REFERENCES `Superpower`(`SuperpowerID`)
);

-- Table structure for table `Organization`
CREATE TABLE `Organization`(
	`OrganizationID` INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
	`OrganizationName` VARCHAR(45) NOT NULL,
	`OrganizationDescription` VARCHAR(45),
    `OrganizationAddress` VARCHAR(45),
	`OrganizationContactInformation` VARCHAR(45)
);


-- Table structure for table `HeroHasOrganization`
CREATE TABLE `HeroHasOrganization`(
	`HeroID` INT UNSIGNED, 
    `OrganizationID` INT UNSIGNED, 
    PRIMARY KEY pk_HeroHasOrganization (`HeroID`,`OrganizationID`),
    FOREIGN KEY fk_HeroHasOrganization_Hero (`HeroID`) REFERENCES `Hero`(`HeroID`),
    FOREIGN KEY fk_HeroHasOrganization_Organization (`OrganizationID`) REFERENCES `Organization`(`OrganizationID`)
);

-- Table structure for table `Location`
CREATE TABLE `Location`(
	`LocationID` INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
	`LocationName` VARCHAR(45) NOT NULL,
	`LocationDescription` VARCHAR(45),
    `LocationAddress` VARCHAR(45),
    `Latitude` VARCHAR(10),
	`Longitude` VARCHAR(10)
);

-- Table structure for table `Signting`
CREATE TABLE `Signting`(
	`SigntingID` INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
	`Date` DATE NOT NULL, 
	`HeroID` INT UNSIGNED, 
    `LocationID` INT UNSIGNED, 
    FOREIGN KEY fk_Signting_Hero (`HeroID`) REFERENCES `Hero`(`HeroID`),
    FOREIGN KEY fk_Signting_Location (`LocationID`) REFERENCES `Location`(`LocationID`)
);
