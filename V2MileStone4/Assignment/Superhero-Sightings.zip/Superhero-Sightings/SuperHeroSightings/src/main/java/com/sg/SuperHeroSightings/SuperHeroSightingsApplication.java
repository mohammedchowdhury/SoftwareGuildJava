package com.sg.SuperHeroSightings;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SuperHeroSightingsApplication {

	public static void main(String[] args) {
		SpringApplication.run(SuperHeroSightingsApplication.class, args);
	}

}
