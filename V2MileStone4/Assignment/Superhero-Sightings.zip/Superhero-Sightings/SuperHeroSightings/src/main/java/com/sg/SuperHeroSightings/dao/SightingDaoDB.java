package com.sg.SuperHeroSightings.dao;

import com.sg.SuperHeroSightings.dto.Hero;
import com.sg.SuperHeroSightings.dto.Location;
import com.sg.SuperHeroSightings.dto.Sighting;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;

/**
 *
 * @author Chelsea, Karma, Mohammed, Patrick
 */
public class SightingDaoDB implements SightingDao {

    @Autowired
    JdbcTemplate jdbc;

    @Override
    public Sighting getSightingById(int id) {
        try {
            final String GET_SIGHTING_BY_ID = "SELECT * FROM Sighting WHERE id = ?";
            return jdbc.queryForObject(GET_SIGHTING_BY_ID, new SightingMapper(), id);
        } catch (DataAccessException ex) {
            return null;
        }
    }

    @Override
    public List<Sighting> getAllSightings() {

        final String GET_ALL_SIGHTINGS = "SELECT * FROM Sighting";
        return jdbc.query(GET_ALL_SIGHTINGS, new SightingMapper());
    }

    @Override
    public Sighting addSighting(Sighting sighting) {
        final String INSERT_SIGHTING = "INSERT INTO Sighting(date, Hero_idHero, Location_idLocation) "
                + "VALUES(?,?,?)";
        jdbc.update(INSERT_SIGHTING,
                sighting.getDate(),
                sighting.getHero().getHeroId(),
                sighting.getLocation().getLocationId());

        int newId = jdbc.queryForObject("SELECT LAST_INSERT_ID()", Integer.class);
        sighting.setSightingId(newId);

        return sighting;
    }

    @Override
    public void updateSighting(Sighting sighting) {
        final String UPDATE_SIGHTING = "UPDATE sighting SET date = ?, Hero_idHero = ?, "
                + "Location_idLocation = ? WHERE idSighting = ?";
        jdbc.update(UPDATE_SIGHTING,
                sighting.getDate(),
                sighting.getHero().getHeroId(),
                sighting.getLocation().getLocationId());

    }

    @Override
    public void deleteSightingById(int id) {

        final String DELETE_SIGHTING = "DELETE FROM Sighting WHERE idSighting = ?";
        jdbc.update(DELETE_SIGHTING, id);
    }

    @Override
    public List<Sighting> getSightingsOfHero(Hero hero) {
        final String GET_SIGHTINGS_BY_HEROES
                = "SELECT * FROM Sighting s"
                + "WHERE s.Hero_idHero = ?";
        List<Sighting> sightings = jdbc.query(GET_SIGHTINGS_BY_HEROES,
                new SightingMapper(), hero.getHeroId());
        return sightings;
    }

    @Override
    public List<Sighting> getSightingsAtLocation(Location location) {
        final String GET_SIGHTINGS_BY_Location
                = "SELECT * FROM Sighting s"
                + "WHERE s.Location_idLocation = ?";
        List<Sighting> sightings = jdbc.query(GET_SIGHTINGS_BY_Location,
                new SightingMapper(), location.getLocationId());
        return sightings;
    }

    @Override
    public List<Sighting> getSightingsFromDate(LocalDate date) {
        final String GET_SIGHTINGS_BY_DATE
                = "SELECT * FROM Sighting s"
                + "WHERE s.date = ?";
        List<Sighting> sightings = jdbc.query(GET_SIGHTINGS_BY_DATE,
                new SightingMapper(), date);
        return sightings;
    }

    public static final class SightingMapper implements RowMapper<Sighting> {

        @Override
        public Sighting mapRow(ResultSet rs, int index) throws SQLException {
            Sighting sighting = new Sighting(rs.getInt("idSighting"));
            sighting.setDate(rs.getDate("date").toLocalDate());
            sighting.setHero(new Hero(rs.getInt("Hero_idHero")));
            sighting.setLocation(new Location(rs.getInt("Location_idLocation")));

            return sighting;
        }
    }

}
