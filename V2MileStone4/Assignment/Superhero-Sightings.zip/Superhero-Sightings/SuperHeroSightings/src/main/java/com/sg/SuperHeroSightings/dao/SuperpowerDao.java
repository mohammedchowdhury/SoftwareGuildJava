package com.sg.SuperHeroSightings.dao;

import com.sg.SuperHeroSightings.dto.Superpower;
import java.util.List;
import org.springframework.stereotype.Repository;

/**
 *
 * @author Chelsea, Karma, Mohammed, Patrick
 */
@Repository
public interface SuperpowerDao {

    //works
    Superpower getSuperpowerById(int id);

    //works
    List<Superpower> getAllSuperpowers();

    //works
    Superpower addSuperpower(Superpower superPower);

    //WORKS
    void updateSuperpower(Superpower superPower);

    //works
    void deleteSuperpowerById(int id);
}
