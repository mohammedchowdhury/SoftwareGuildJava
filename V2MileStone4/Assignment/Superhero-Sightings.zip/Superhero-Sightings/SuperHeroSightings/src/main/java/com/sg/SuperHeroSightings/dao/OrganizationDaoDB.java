package com.sg.SuperHeroSightings.dao;

import com.sg.SuperHeroSightings.dto.Hero;
import com.sg.SuperHeroSightings.dto.Location;
import com.sg.SuperHeroSightings.dto.Organization;
import com.sg.SuperHeroSightings.dto.Superpower;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;

/**
 *
 * @author Chelsea, Karma, Mohammed, Patrick
 */
@Repository
public class OrganizationDaoDB implements OrganizationDao {

    @Autowired
    JdbcTemplate jdbc;

    @Override
    public Organization getOrganizationById(int id) {
        try {
            final String GET_ORGANIZATION_BY_ID = "SELECT * FROM Organization WHERE id = ?";
            return jdbc.queryForObject(GET_ORGANIZATION_BY_ID, new OrganizationMapper(), id);
        } catch (DataAccessException ex) {
            return null;
        }
    }

    @Override
    public List<Organization> getAllOrganizations() {
        final String GET_ALL_ORGANIZATIONS = "SELECT * FROM Organization";
        return jdbc.query(GET_ALL_ORGANIZATIONS, new OrganizationMapper());
    }

    @Override
    public Organization addOrganization(Organization organization) {
        final String INSERT_ORGANIZATION = "INSERT INTO Organization(name, description, Location_idLocation, contactEmail, contactPhone) "
                + "VALUES(?,?,?,?,?)";
        jdbc.update(INSERT_ORGANIZATION,
                organization.getOrganizationName(),
                organization.getOrganizationDescription(),
                organization.getLocation().getLocationId(),
                organization.getOrganizationEmail(),
                organization.getOrganizationPhone());

        int newId = jdbc.queryForObject("SELECT LAST_INSERT_ID()", Integer.class);
        organization.setOrganizationId(newId);
        insertOrganizationHero(organization);
        return organization;
    }

    @Override
    public void updateOrganization(Organization organization) {
        final String UPDATE_ORGANIZATION = "UPDATE organization SET name = ?, description = ?, "
                + "Location_idLocation = ?, contactEmail = ?, contactPhone = ?  WHERE idOrganization = ?";
        jdbc.update(UPDATE_ORGANIZATION,
                organization.getOrganizationName(),
                organization.getOrganizationDescription(),
                organization.getLocation().getLocationId(),
                organization.getOrganizationEmail(),
                organization.getOrganizationPhone());

        final String DELETE_HERO_ORGANIZATION = "DELETE FROM HeroOrganization WHERE Organization_idOrganization = ?";
        jdbc.update(DELETE_HERO_ORGANIZATION, organization.getOrganizationId());
        insertOrganizationHero(organization);
    }

    @Override
    public void deleteOrganizationById(int id) {
        final String DELETE_ORGANIZATION_FROM_HERO = "DELETE FROM HeroOrganization WHERE Organization_idOrganization = ?";
        jdbc.update(DELETE_ORGANIZATION_FROM_HERO, id);

        final String DELETE_ORGANIZATION = "DELETE FROM Organization WHERE idOrganization = ?";
        jdbc.update(DELETE_ORGANIZATION, id);
    }

    @Override
    public List<Organization> getOrganizationsbyHero(Hero hero) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    private void insertOrganizationHero(Organization organization) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    public static final class OrganizationMapper implements RowMapper<Organization> {

        @Override
        public Organization mapRow(ResultSet rs, int index) throws SQLException {
            Organization organization = new Organization(rs.getInt("idOrganization"));
            organization.setOrganizationName(rs.getString("name"));
            organization.setOrganizationDescription(rs.getString("description"));
            organization.setLocation(new Location(rs.getInt("Location_idLocation")));
            organization.setOrganizationEmail(rs.getString("contactEmail"));
            organization.setOrganizationPhone(rs.getInt("contactPhone"));

            return organization;
        }
    }
}
