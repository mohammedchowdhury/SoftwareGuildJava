package com.sg.SuperHeroSightings.dao;

import com.sg.SuperHeroSightings.dao.HeroDaoDB.HeroMapper;
import com.sg.SuperHeroSightings.dto.Hero;
import com.sg.SuperHeroSightings.dto.Location;
import com.sg.SuperHeroSightings.dto.Organization;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

/**
 *
 * @author Chelsea, Karma, Mohammed, Patrick
 */
@Repository
public class LocationDaoDB implements LocationDao {

    @Autowired
    JdbcTemplate jdbc;

    //works
    @Override
    public Location getLocationById(int id) {
        try {
            final String GET_LOCATION_BY_ID = "SELECT * FROM Location WHERE idLocation = ?";
            return jdbc.queryForObject(GET_LOCATION_BY_ID, new LocationMapper(), id);
        } catch (DataAccessException ex) {
            return null;
        }
    }

    //works
    @Override
    public List<Location> getAllLocations() {

        final String GET_ALL_LOCATIONS = "SELECT * FROM Location";
        return jdbc.query(GET_ALL_LOCATIONS, new LocationMapper());
    }

    //works
    @Override
    @Transactional
    public Location addLocation(Location location) {
        final String INSERT_LOCATION = "INSERT INTO Location(name, description, address, city, state, country, zipcode, latitude, longitude) "
                + "VALUES(?,?,?,?,?,?,?,?,?)";
        try {
            jdbc.update(INSERT_LOCATION,
                    location.getLocationName(),
                    location.getLocationDescription(),
                    location.getLocationAddress(),
                    location.getLocationCity(),
                    location.getLocationState(),
                    location.getCountry(),
                    location.getZipCode(),
                    location.getLatitude(),
                    location.getLongitude());
            int newId = jdbc.queryForObject("SELECT LAST_INSERT_ID()", Integer.class);
            location.setLocationId(newId);
        } catch (Exception e) {
            return null;
        }
        return location;
    }

    //works
    @Override
    public void updateLocation(Location location) {
        final String UPDATE_LOCATION = "UPDATE Location "
                + "SET Location.name = ?, Location.description = ?, "
                + "Location.address = ?, Location.city = ?, Location.state = ?, "
                + "Location.country = ?, Location.zipcode = ?, Location.latitude = ?,"
                + "longitude = ?  WHERE idLocation = ?";
        jdbc.update(UPDATE_LOCATION,
                location.getLocationName(),
                location.getLocationDescription(),
                location.getLocationAddress(),
                location.getLocationCity(),
                location.getLocationState(),
                location.getCountry(),
                location.getZipCode(),
                location.getLatitude(),
                location.getLongitude(),
                location.getLocationId());
    }
    //works
    @Override
    @Transactional
    public void deleteLocationById(int id) {

        final String DELETE_HeroOrginization = "DELETE FROM HeroOrganization "
                + "WHERE Organization_idOrganization IN ("
                + "SELECT Organization.idOrganization "
                + "FROM Organization "
                + "INNER JOIN Location ON Location.idLocation = Organization.Location_idLocation "
                + "WHERE Location.idLocation = ?);";
        jdbc.update(DELETE_HeroOrginization, id);

        final String DELETE_ORGINIZATION = "DELETE FROM Organization "
                + "WHERE Organization.Location_idLocation = ? ;";
        jdbc.update(DELETE_ORGINIZATION, id);

        final String DELETE_SIGHTING = "DELETE FROM Sighting "
                + "WHERE Sighting.Location_idLocation = ?;";
        jdbc.update(DELETE_SIGHTING, id);

        final String DELETE_LOCATION = "DELETE FROM Location "
                + "WHERE Location.idLocation = ?;";
        jdbc.update(DELETE_LOCATION, id);

        List<Hero> listOfHerosToBeDeleted;

        final String GET_LIST_OF_HEROS = "SELECT * "
                + "FROM Hero "
                + "WHERE Hero.idHero NOT IN ( "
                + "SELECT HeroOrganization.Hero_idHero "
                + "FROM HeroOrganization); ";

        listOfHerosToBeDeleted = jdbc.query(GET_LIST_OF_HEROS, new HeroMapper());

        for (Hero hero : listOfHerosToBeDeleted) {
            final String DELETER_HERO_BY_ID = "DELETE FROM Hero "
                    + "WHERE Hero.idHero = ?;";
            jdbc.update(DELETER_HERO_BY_ID, hero.getHeroId());
        }
    }

    public static final class LocationMapper implements RowMapper<Location> {

        @Override
        public Location mapRow(ResultSet rs, int index) throws SQLException {
            Location location = new Location(rs.getInt("idLocation"));
            location.setLocationName(rs.getString("name"));
            location.setLocationDescription(rs.getString("description"));
            location.setLocationAddress(rs.getString("address"));
            location.setLocationCity(rs.getString("city"));
            location.setLocationState(rs.getString("state"));
            location.setCountry(rs.getString("country"));
            location.setZipCode(rs.getString("zipCode"));
            location.setLatitude(rs.getBigDecimal("latitude"));
            location.setLongitude(rs.getBigDecimal("longitude"));
            return location;
        }
    }
}