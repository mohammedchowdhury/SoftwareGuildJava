
package com.sg.SuperHeroSightings.dao;

import com.sg.SuperHeroSightings.dto.Location;
import java.util.List;
import org.springframework.stereotype.Repository;

/**
 *
 * @author Chelsea, Karma, Mohammed, Patrick
 */
@Repository
public interface LocationDao {
    
    Location getLocationById(int id);

    List<Location> getAllLocations();

    Location addLocation(Location location);

    void updateLocation(Location location);

    void deleteLocationById(int id);
}
