package com.sg.SuperHeroSightings;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SuperHeroSightingsApplicationTests {

	@Test
	void contextLoads() {
	}

}
