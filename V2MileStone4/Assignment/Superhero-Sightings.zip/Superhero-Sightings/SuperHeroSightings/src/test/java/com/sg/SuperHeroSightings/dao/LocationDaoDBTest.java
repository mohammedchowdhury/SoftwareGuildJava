package com.sg.SuperHeroSightings.dao;

import com.sg.SuperHeroSightings.dto.Location;
import java.math.BigDecimal;
import java.util.List;
import org.junit.After;
import static org.junit.Assert.assertEquals;
import org.junit.Before;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

/**
 *
 * @author Chelsea, Karma, Mohammed, Patrick
 */
@RunWith(SpringRunner.class)
@SpringBootTest
public class LocationDaoDBTest {

    @Autowired
    LocationDao locationDao;

    @After
    public void setUp2() {
        List<Location> listOfLocation = locationDao.getAllLocations();
        for (Location loc : listOfLocation) {
            locationDao.deleteLocationById(loc.getLocationId());
        }
    }

    @Before
    public void setUp() {
        List<Location> listOfLocation = locationDao.getAllLocations();
        for (Location loc : listOfLocation) {
            locationDao.deleteLocationById(loc.getLocationId());
        }
    }

    public LocationDaoDBTest() {
    }

    @Test
    public void TestgetLocationById() {
        //arrange 
        Location location1 = new Location();
        location1.setLocationName("Elmhurst Hospital");
        location1.setLocationDescription("Hospital");
        location1.setLocationAddress("79-01 Broadway, Elmhurst, NY 11373");
        location1.setLocationCity("Elmhurst");
        location1.setLocationState("New York");
        location1.setCountry("USA");
        location1.setZipCode("11373");
        location1.setLatitude(new BigDecimal("40.744715"));
        location1.setLongitude(new BigDecimal("-73.885605"));
        //act
        location1 = locationDao.addLocation(location1);
        Location location2 = locationDao.getLocationById(location1.getLocationId());
        //assert
        assertEquals(location1, location2);
    }

    @Test
    public void TestupdateLocation() {
        //arrange 
        Location location1 = new Location();
        location1.setLocationName("Elmhurst Hospital");
        location1.setLocationDescription("Hospital");
        location1.setLocationAddress("79-01 Broadway, Elmhurst, NY 11373");
        location1.setLocationCity("Elmhurst");
        location1.setLocationState("New York");
        location1.setCountry("USA");
        location1.setZipCode("11373");
        location1.setLatitude(new BigDecimal("40.744715"));
        location1.setLongitude(new BigDecimal("-73.885605"));
        //act
        location1 = locationDao.addLocation(location1);
        location1.setZipCode("11354");
        location1.setLocationState("NY");
        locationDao.updateLocation(location1);
        Location updatedLocation = locationDao.getLocationById(location1.getLocationId());
        //assert
        assertEquals(location1, updatedLocation);
    }

    @Test
    public void TestdeleteLocationById() {
        //arrange 
        Location location1 = new Location();
        location1.setLocationName("Elmhurst Hospital");
        location1.setLocationDescription("Hospital");
        location1.setLocationAddress("79-01 Broadway, Elmhurst, NY 11373");
        location1.setLocationCity("Elmhurst");
        location1.setLocationState("New York");
        location1.setCountry("USA");
        location1.setZipCode("11373");
        location1.setLatitude(new BigDecimal("40.744715"));
        location1.setLongitude(new BigDecimal("-73.885605"));
        //act
        location1 = locationDao.addLocation(location1);
        locationDao.deleteLocationById(location1.getLocationId());
        location1 = locationDao.getLocationById(location1.getLocationId());
        //assert
        assertEquals(location1, null);
    }

    @Test
    public void TestgetAllLocations() {
        //arrange 
        Location location1 = new Location();
        location1.setLocationName("Elmhurst Hospital");
        location1.setLocationDescription("Hospital");
        location1.setLocationAddress("79-01 Broadway, Elmhurst, NY 11373");
        location1.setLocationCity("Elmhurst");
        location1.setLocationState("New York");
        location1.setCountry("USA");
        location1.setZipCode("11373");
        location1.setLatitude(new BigDecimal("40.744715"));
        location1.setLongitude(new BigDecimal("-73.885605"));
        location1 = locationDao.addLocation(location1);

        Location location2 = new Location();
        location2.setLocationName("Elmhurst");
        location2.setLocationDescription("Park");
        location2.setLocationAddress("79-01 Broadway, Elmhurst, NY 11373");
        location2.setLocationCity("Elmhurst");
        location2.setLocationState("New York");
        location2.setCountry("USA");
        location2.setZipCode("11373");
        location2.setLatitude(new BigDecimal("40.744715"));
        location2.setLongitude(new BigDecimal("-73.885605"));
        location2 = locationDao.addLocation(location2);

        //act 
        List<Location> listOfLocations = locationDao.getAllLocations();
        int size = 2;
        int actual = listOfLocations.size();
        //assert
        assertEquals(actual, size);

    }
}
