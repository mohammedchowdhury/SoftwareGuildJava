/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.sg.SuperHeroSightings.dao;

import com.sg.SuperHeroSightings.dto.Superpower;
import java.util.List;
import org.junit.After;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

/**
 *
 * @author mohammedchowdhury
 */
@RunWith(SpringRunner.class)
@SpringBootTest
public class SuperpowerDaoDBTest {

    @Autowired
    SuperpowerDao superpowerdao;

    public SuperpowerDaoDBTest() {
    }

//    @Before
//    public void setUp() {
//        List<Superpower> listOfSuperPower = superpowerdao.getAllSuperpowers();
//        for (Superpower superpower : listOfSuperPower) {
//            superpowerdao.deleteSuperpowerById(superpower.getSuperPowerId());
//        }
//    }
//
//    @After
//    public void setUp2() {
//        List<Superpower> listOfSuperPower = superpowerdao.getAllSuperpowers();
//        for (Superpower superpower : listOfSuperPower) {
//            superpowerdao.deleteSuperpowerById(superpower.getSuperPowerId());
//        }
//    }

    @Test
    public void TestaddSuperpower() {
        //arrange
        Superpower superpower1 = new Superpower();
        superpower1.setSuperPowerName("Flying");
        //act
        superpower1 = superpowerdao.addSuperpower(superpower1);
        Superpower superpower2 = superpowerdao.getSuperpowerById(superpower1.getSuperPowerId());
        //assert
        assertEquals(superpower1, superpower2);

    }

    @Test
    public void TestgetSuperpowerById() {
        //arrange
        Superpower superpower1 = new Superpower();
        superpower1.setSuperPowerName("Flying");
        //act
        superpower1 = superpowerdao.addSuperpower(superpower1);
        Superpower superpower2 = superpowerdao.getSuperpowerById(superpower1.getSuperPowerId());
        //assert
        assertEquals(superpower1, superpower2);

    }

    @Test
    public void TestupdateSuperpower() {
        //arrange
        Superpower superpower1 = new Superpower();
        superpower1.setSuperPowerName("Flying");
        //act
        superpower1 = superpowerdao.addSuperpower(superpower1);
        superpower1.setSuperPowerName("Fighting");
        superpowerdao.updateSuperpower(superpower1);
        Superpower superpower2 = superpowerdao.getSuperpowerById(superpower1.getSuperPowerId());
        //assert
        assertEquals(superpower1, superpower2);
    }

    @Test
    public void TestgetAllSuperpowers() {
        //arrange
        Superpower superpower1 = new Superpower();
        superpower1.setSuperPowerName("Flying");

        Superpower superpower2 = new Superpower();
        superpower2.setSuperPowerName("Flying");

        //act
        superpower1 = superpowerdao.addSuperpower(superpower1);
        superpower2 = superpowerdao.addSuperpower(superpower2);
        List<Superpower> listOfSuperPower = superpowerdao.getAllSuperpowers();
        int size = 2, actual = listOfSuperPower.size();
        //assert
        assertEquals(2, actual);
        assertTrue(listOfSuperPower.contains(superpower1));
        assertTrue(listOfSuperPower.contains(superpower2));

    }

    @Test
    public void TestdeleteSuperpowerById() {
        //arrange
        Superpower superpower1 = new Superpower();
        superpower1.setSuperPowerName("Flying");

        Superpower superpower2 = new Superpower();
        superpower2.setSuperPowerName("Flying");

        //act
        superpower1 = superpowerdao.addSuperpower(superpower1);
        superpower2 = superpowerdao.addSuperpower(superpower2);
        superpowerdao.deleteSuperpowerById(superpower1.getSuperPowerId());
        superpowerdao.deleteSuperpowerById(superpower2.getSuperPowerId());
        
        List<Superpower> listOfSuperPower = superpowerdao.getAllSuperpowers();
        int size = 0, actual = listOfSuperPower.size();
        //assert
        assertEquals(0, actual);
        assertTrue(!listOfSuperPower.contains(superpower1));
        assertTrue(!listOfSuperPower.contains(superpower2));
    }

}
